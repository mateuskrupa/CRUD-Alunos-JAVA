package br.com.unicuritiba.crudalunos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CrudAlunosApplicationTests {

	@Test
	void contextLoads() {
	}

}
