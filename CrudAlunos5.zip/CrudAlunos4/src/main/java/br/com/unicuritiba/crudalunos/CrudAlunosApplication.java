package br.com.unicuritiba.crudalunos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CrudAlunosApplication {

	public static void main(String[] args) {
		SpringApplication.run(CrudAlunosApplication.class, args);
	}

}
