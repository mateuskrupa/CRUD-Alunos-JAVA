package br.com.unicuritiba.crudalunos.controller;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.ModelAndView;

import br.com.unicuritiba.crudalunos.model.Aluno;
import br.com.unicuritiba.crudalunos.repository.AlunoRepository;
@Controller

public class AlunosController {
	
	@Autowired
	AlunoRepository repository;
	
	@GetMapping("/alunos")
	public ModelAndView listarAlunos() {		
		
		ModelAndView modelAlunos = new ModelAndView("listar_alunos");
		
		List<Aluno> listaAlunos = repository.findAll();		
		
		modelAlunos.addObject("professor", "Diego Palma");
		modelAlunos.addObject("alunos", listaAlunos);
		return modelAlunos;
	}
	
	@GetMapping("/cadastro-aluno")
	public ModelAndView cadastroAlunos() {		
		
		ModelAndView modelAlunos = new ModelAndView("criarAluno");
		
		modelAlunos.addObject("aluno", new Aluno());
		
		
		return modelAlunos;
	
	}
		
	
	@PostMapping("/cadastro-aluno")
	public ModelAndView criarAluno(@ModelAttribute Aluno aluno) {
		
		repository.save(aluno);
			
		ModelAndView modelAlunos = new ModelAndView("redirect:/alunos");
		return modelAlunos;
		
		
		
	}
}
	
