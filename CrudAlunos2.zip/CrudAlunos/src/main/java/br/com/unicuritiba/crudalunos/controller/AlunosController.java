package br.com.unicuritiba.crudalunos.controller;
import java.util.ArrayList;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.ModelAndView;
import br.com.unicuritiba.crudalunos.model.Aluno;
@Controller

public class AlunosController {
	
	@GetMapping("/alunos")
	public ModelAndView listarAlunos() {		
		
		ModelAndView modelAlunos = new ModelAndView("listar_alunos");
		
		Aluno aluno = new Aluno(
				"Joao da Silva",
				2,
				"16/10/1999",
				"joao@gmail.com",
				"16565465465",
				"masculino");
		
		ArrayList<Aluno> listaAlunos = new ArrayList<>();
		listaAlunos.add(aluno);		
		
		modelAlunos.addObject("professor", "Diego Palma");
		modelAlunos.addObject("alunos", listaAlunos);
		return modelAlunos;
	}
	
	@GetMapping("/cadastro-aluno")
	public ModelAndView cadastroAlunos() {		
		
		ModelAndView modelAlunos = new ModelAndView("criarAluno");
		
		modelAlunos.addObject("aluno", new Aluno());
		
		
		return modelAlunos;
	
	}
		
	
	@PostMapping("/cadastro-aluno")
	public ModelAndView criarAluno() {		
			
		ModelAndView modelAlunos = new ModelAndView("criarAluno");
		return modelAlunos;
		
		
		
	}
}
	
