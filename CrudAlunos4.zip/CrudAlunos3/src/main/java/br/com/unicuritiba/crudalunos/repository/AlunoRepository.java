package br.com.unicuritiba.crudalunos.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import br.com.unicuritiba.crudalunos.model.Aluno;

public interface AlunoRepository extends JpaRepository<Aluno, Long>{

}
