package br.com.unicuritiba.crudalunos.controller;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.servlet.ModelAndView;

import br.com.unicuritiba.crudalunos.model.Aluno;
import br.com.unicuritiba.crudalunos.repository.AlunoRepository;
@Controller

public class AlunosController {
	
	@Autowired
	AlunoRepository repository;
	
	@GetMapping("/alunos")
	public ModelAndView listarAlunos() {		
		
		ModelAndView modelAlunos = new ModelAndView("listar_alunos");
		
		List<Aluno> listaAlunos = repository.findAll();		
		
		modelAlunos.addObject("professor", "Diego Palma");
		modelAlunos.addObject("alunos", listaAlunos);
		return modelAlunos;
	}
	
	@DeleteMapping("/alunos/{id}")
	public ModelAndView deletarAluno(@PathVariable("id") int alunoId) {
		
		repository.deleteById((long)alunoId);
		
		return new ModelAndView("redirect:/alunos");	
	}
	
	@PutMapping("/alunos/{id}")
	public ModelAndView atualizarAlunos(@PathVariable("id") int alunoId,
										@ModelAttribute Aluno aluno) {
		aluno.setId(alunoId);
		repository.save(aluno);
		return new ModelAndView("redirect:/alunos");
	}
	
	@GetMapping("/alunos/{id}")
	public ModelAndView vizualizaAlunos(@PathVariable("id") int alunoId) {		
		
		ModelAndView modelAlunos = new ModelAndView("atualizar_aluno");
		
		Aluno aluno = repository.findById((long)alunoId).get();
		
		modelAlunos.addObject("aluno", aluno);
		
		
		return modelAlunos;
	
	}
	
	
	@GetMapping("/cadastro-aluno")
	public ModelAndView cadastroAlunos() {		
		
		ModelAndView modelAlunos = new ModelAndView("criarAluno");
		
		modelAlunos.addObject("aluno", new Aluno());
		
		
		return modelAlunos;
	
	}
		
	
	@PostMapping("/cadastro-aluno")
	public ModelAndView criarAluno(@ModelAttribute Aluno aluno) {
		
		repository.save(aluno);
			
		ModelAndView modelAlunos = new ModelAndView("redirect:/alunos");
		return modelAlunos;
		
		
		
	}
}
	
